export interface MapLocation {
  name: string;
  xPct: number;
  yPct: number;
}

// Coordinates are percentages of the natural width/height of
// /public/images/map/known-world.webp, so they stay correct at any
// display size. Logged with the /map-locator tool.
// x sol sağ - y yukarı aşağı
export const MAP_LOCATIONS: MapLocation[] = [
  { name: "King's Landing", xPct: 19.31, yPct: 50.99 },
  { name: "Storm's End", xPct: 22.45, yPct: 56.03 },
  { name: "Dragonstone", xPct: 23.53, yPct: 47.61 },
  { name: "Driftmark", xPct: 22.25, yPct: 48.23 },
  { name: "Starfall", xPct: 12.0, yPct: 64.03 },
  { name: "Oldtown", xPct: 9.35, yPct: 62.08 },
  { name: "Highgarden", xPct: 12.56, yPct: 57.98 },
  { name: "Sunspear", xPct: 23.50, yPct: 65.69 },
  { name: "Stepstones", xPct: 26.32, yPct: 61.88 },
  { name: "Harrenhal", xPct: 18.36, yPct: 45.62 },
  { name: "The Eyrie", xPct: 20.96, yPct: 40.96 },
  { name: "The Twins", xPct: 15.86, yPct: 38.81 },
  { name: "Moat Cailin", xPct: 16.49, yPct: 32.2 },
  { name: "Winterfell", xPct: 15.55, yPct: 24.60 },
  { name: "Castle Black", xPct: 18.45, yPct: 14.95 },
  { name: "Riverrun", xPct: 15, yPct: 44 },
  { name: "Casterly Rock", xPct: 10.28, yPct: 48.38 },
  { name: "Braavos", xPct: 29.27, yPct: 37.1 },
  { name: "Valyria", xPct: 43.66, yPct: 78.06 },
  { name: "The Dreadfort", xPct: 20.68, yPct: 23.83 },
  { name: "White Harbor", xPct: 18.68, yPct: 30.97 },
  { name: "Naath", xPct: 42.83, yPct: 92.74 },
  { name: "Gulltown", xPct: 24.67, yPct: 42.76 },
  { name: "Pyke", xPct: 10.53, yPct: 42.09 },
  { name: "Ashford", xPct: 16.29, yPct: 57.38 },
  { name: "Bitterbridge", xPct: 14.95, yPct: 53.90 },
  { name: "Summerhall", xPct: 19.21, yPct: 57.09 },
  { name: "Rook's Rest", xPct: 22.22, yPct: 47.14 },
  { name: "Kingswood", xPct: 20.63, yPct: 52.7 },
  { name: "Blackwater Bay", xPct: 22, yPct: 50.1 },
  { name: "Duskendale", xPct: 21.08, yPct: 48.6 },
  { name: "Pentos", xPct: 29.39, yPct: 50.24 },
  { name: "Tyrosh", xPct: 27.33, yPct: 59.47 },
  { name: "Myr", xPct: 31.25, yPct: 58.83 },
  { name: "Lys", xPct: 29.6, yPct: 66.4 },
  { name: "Volantis", xPct: 38.76, yPct: 66.21 },
  { name: "Astapor", xPct: 52.63, yPct: 69.43 },
  { name: "Yunkai", xPct: 53.54, yPct: 64.27 },
  { name: "Meereen", xPct: 54.86, yPct: 62.35 },
  { name: "Asshai", xPct: 90.64, yPct: 94.1 },
  { name: "The Red Mountains", xPct: 12.67, yPct: 61.13 },
  { name: "The Prince's Pass", xPct: 15.03, yPct: 61.47 },
  { name: "The Dornish Marches", xPct: 15.09, yPct: 58.87 },
];

export const MAP_LOCATION_NAMES = MAP_LOCATIONS.map((l) => l.name);

const locationIndex = new Map(MAP_LOCATIONS.map((l) => [l.name, l]));

export function getMapLocation(name: string): MapLocation | undefined {
  return locationIndex.get(name);
}

export const DEFAULT_MAP_LOCATION = "King's Landing";
export const DEFAULT_MAP_FOCUS_SCALE = 0.7;

