import type { Chapter } from "@/types/chapter";

const chapter: Chapter = {
  slug: "the-price-of-trust",
  title: "Chapter II: The Price of Trust",
  synopsis:
    "A deception surrounding the assassin spirals into political tension, exposing fractures within the royal family.",
  image: "/images/chapters/the-price-of-trust.webp",
  content: [
  "If the hatching of dragons had marked the beginning of the realm's unrest, the feast that followed revealed something far more dangerous.",

  "Not every wound bled.",

  "Some smiled.",

  "Some drank.",

  "Some wore a chain of office.",

  "Prince Gaelor was the first to move.",

  "The man who had confessed with his dying breath that the Hand had ordered the poisoning was already beyond questioning. Dead men told no tales. Yet the prince refused to let the trail end there. Hidden among the assassin's belongings was a scrap of parchment bearing the markings of the Iron Bank, account numbers and records of payments that no common cutthroat should ever possess.",

  "It was not proof.",

  "But it was enough to weave a snare.",

  "A sellsword from the south, broad-shouldered and dark of skin, was bought with gold and silence. His head was covered with a hood, chains clasped around his wrists, and he was cast into the dungeons as though he were the very poisoner who had tried to kill the king.",

  "The trap was simple.",

  "Let the realm believe the assassin still lived.",

  "Then wait to see who came to finish him.",

  "Jacaelon approved the deception at once.",

  "Yet the prince trusted evidence more than instinct. Before any accusations could be whispered, he proposed another path.",

  "“Compare the writing.”",

  "While Gaelor and Visenor occupied the king and his Hand in the throne room, Jace slipped through the corridors with Princess Saera beside him. Together they entered the council chamber like ghosts beneath candlelight.",

  "Letters.",

  "Ledgers.",

  "Wax seals.",

  "Reports from distant lords.",

  "The desk of the Hand held enough secrets to drown a kingdom.",

  "Yet none of them matched.",

  "The handwriting upon the bank records belonged to another.",

  "Not Derrin Hightower.",

  "Not unless another hand had penned his crimes.",

  "They found no answers before footsteps echoed through the halls.",

  "Gaelor delayed the Hand with cups of wine and drunken laughter until the search was finished. It was enough.",

  "The parchment remained a mystery.",

  "The trap would have to suffice.",

  "That evening the royal family gathered beneath golden chandeliers while servants poured wine as though the court had never smelled poison.",

  "Visenor sat beside Lady Rhaella.",

  "She had asked him only hours before whether she would still have been his wife had there been no letters.",

  "He could not answer.",

  "Instead they had clung to one another like two souls already mourning a future neither believed would come.",

  "King Baelenys broke the silence.",

  "“So,” he asked. “I hear my children have been making plans.”",

  "Gaelor spoke first.",

  "The false prisoner.",

  "The interrogation.",

  "The silent assassin.",

  "The king listened without interruption.",

  "At first.",

  "Then Visenor spoke of delaying the war.",

  "The room seemed to breathe easier.",

  "For only a heartbeat.",

  "Baelenys rose from his chair.",

  "His boots echoed across the stone floor as he strode toward the great hearth. The fire answered him with a sudden crack, sending sparks dancing into the air. Rage rolled from the king in silent waves. For a fleeting moment, it seemed as though the chamber itself had become the chest of some slumbering dragon, drawing slow, heavy breaths before unleashing fire upon the world.",

  "Without warning he withdrew a folded letter from within his robes and flung it across the table.",

  "It struck Visenor squarely in the face.",

  "“What,” the king asked, his voice colder than winter seas, “is this?”",

  "No one answered.",

  "Rhaella paled.",

  "Saera lowered her eyes.",

  "Jace understood at once.",

  "They had not been keeping secrets from the king.",

  "Only from themselves.",

  "Baelenys already knew.",

  "He mocked Saera's spies.",

  "Mocked Visenor's lies.",

  "Mocked Jace's silence.",

  "When Jace defended himself, saying he had first informed the heir because it was proper, because to go behind his brother's back would have sown discord within the royal family, the king's anger only deepened.",

  "Trust.",

  "Honor.",

  "Duty.",

  "Baelenys had no patience left for such words.",

  "He stripped Blackfyre from Visenor's hands before the entire court and placed the ancient sword in Gaelor's keeping.",

  "Steel changed hands.",

  "So too did favor.",

  "Visenor stared at the empty place where Blackfyre had rested only moments before.",

  "“Father… I never meant to deceive you. I only feared what might become of Rhaella. I thought...”",

  "He never finished.",

  "Baelenys crossed the distance between them with startling speed.",

  "The crack of the slap echoed through the hall like the report of a whip.",

  "Visenor collapsed onto the stone floor before anyone could move. Two bloodied teeth skipped across the flagstones, spinning to a halt beneath the long table.",

  "No one breathed.",

  "No one spoke.",

  "The only sound was the faint crackling of the fire.",

  "Jacaelon was the first to move.",

  "He dropped to one knee beside his brother, slipping an arm beneath his shoulders to help him rise.",

  "Visenor's mouth was filled with blood.",

  "For the briefest moment, Jace forgot the intrigues, the lies, the rivalries, the crown itself.",

  "All he saw was his brother.",

  "Baelenys looked down upon them without remorse.",

  "“Next time,” the king said, his voice as cold as forged steel, “remember who it is you dare disappoint.”",

  "Little Princess Vhaemys buried her face against the table, unable to watch.",

  "Only then did Jace look back at his father.",

  "He said nothing.",

  "But something behind his violet eyes had changed.",

  "Jace's suspicions refused to die.",

  "As the Hand departed, the prince silently caught Ser Alester Dayne's eye.",

  "Follow him.",

  "The knight needed no words.",

  "Derrin Hightower descended into the dungeons exactly as Jace had predicted.",

  "He demanded the prisoner.",

  "The guards refused.",

  "Saathos barred the way.",

  "Then Ser Alester himself appeared, calm as still water.",

  "“My prince's orders,” he said.",

  "For several long moments the Hand measured the two knights.",

  "He left empty-handed.",

  "No confession.",

  "No proof.",

  "Yet no innocent man would have hurried to a prison cell before dawn.",

  "That night Baelenys summoned Visenor alone.",

  "The hall felt less like a throne room than a place of judgment.",

  "“I trusted you,” the king said.",

  "“I did not love you. Love is for mothers and fools. I trusted you.”",

  "Then came the choice.",

  "Dragonstone.",

  "Or blood.",

  "Leave the court forever…",

  "…or kill your own wife and earn your king's trust anew.",

  "Visenor left without giving an answer.",

  "Only after the doors closed did he begin to understand the man who had raised him.",

  "He found Jace and Gaelor waiting.",

  "“I must flee,” he said. “Rhaella and I cannot stay.”",

  "“Essos,” he whispered.",

  "Gaelor rejected the idea before the words had finished leaving his mouth.",

  "Voices rose.",

  "Tempers followed.",

  "“Not here,” Visenor pleaded. “Somewhere private.”",

  "The three princes withdrew to Gaelor's chambers.",

  "The argument worsened.",

  "Gaelor called him a coward.",

  "Visenor spoke of mercy.",

  "Then Jace stepped forward.",

  "“I have never seen a man as spineless as you.”",

  "He shoved the heir hard enough for him to stagger.",

  "“You've learned nothing.”",

  "Only Visenor heard the whisper that followed.",

  "“My chambers.”",

  "When the performance was complete, Jace walked away without another word.",

  "Later that night Visenor entered his brother's chambers in secret.",

  "“Why did you call for me?”",

  "Jace looked at him for a long while.",

  "Then finally answered.",

  "“I'll do it.”",

  "“I'll help you.”",

  "Hope flickered across Visenor's face.",

  "It died just as quickly.",

  "“You are not going to Essos.”",

  "Jace spoke not as a brother, but as a prince.",

  "“If you cross the Narrow Sea, you become a claimant in exile. Your wife's family, our uncle, every enemy of this house will use your name. Whether willingly or in chains, you would become the spark that burns the Seven Kingdoms.”",

  "“There is another road.”",

  "“Dorne.”",

  "Torrentine.",

  "Far from King's Landing.",

  "Far from the king.",

  "Close enough to disappear.",

  "Ser Alester Dayne accepted the task without hesitation.",

  "No oath was spoken.",

  "None was needed.",

  "The escape began beneath a moon veiled by clouds.",

  "Alester procured a humble wagon that looked fit only for merchants and beggars. He crossed forgotten passages beneath the castle, where damp stone swallowed every footstep.",

  "One guard fell unconscious before he knew another man shared the corridor.",

  "Two more followed.",

  "The knight left them breathing.",

  "Only sleeping.",

  "A pebble struck Visenor's window.",

  "Once.",

  "Twice.",

  "The prince descended with Rhaella carrying what little remained of their lives: coin, provisions, and hope.",

  "The wagon rolled into the darkness.",

  "Not far behind, voices shouted.",

  "Torches bloomed across the castle walls.",

  "The chase had begun.",

  "Before they departed, Jace gave Alester one final command.",

  "“When you return, you were never escorting a prince.”",

  "“You went to Dorne to bring Lorenah Dayne to court.”",

  "“If anyone asks...”",

  "“...that is the only story that ever happened.”",

  "Alester nodded.",

  "He never looked back.",

  "Sleep abandoned Jacaelon that night.",

  "Every sound beyond his chamber door became footsteps coming for him.",

  "Every gust of wind became a raven bearing terrible news.",

  "Had Alester crossed the border?",

  "Had Visenor been caught?",

  "Would Baelenys already know?",

  "Three riderless dragons still remained within the castle.",

  "Three dragons.",

  "Three loose ends.",

  "And somewhere within the Red Keep, Jacaelon Targaryen finally understood a truth his father had known for years.",

  "The hardest lies were never told to enemies.",

  "Only to those one loved."
  ],
};

export default chapter;